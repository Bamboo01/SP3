FreeType 2.10.1
=========================
###### Windows binaries (DLL) of FreeType (win32/win64)
Compiled with VS Express 2017 (SDK 10.0.17763)
> *freetype.dll* uses the *Universal CRT* and therefore **_requires_** Visual C++ 2015-2019 Redistributable to be present on system.
###### Supported operating systems
- Windows 10 version 1507 or higher
- Windows Server 2016
- Windows 8.1
- Windows Server 2012 R2
- Windows 7 SP1
###### File hash values
| filename | sha256 |
| :-- | :-- |
| win32\\**freetype.dll** | `0B8ADF00D7CBAA8297AC350C30FD9C89C1D21AFB4052492AF5F5E242CA8420BA` |
| win32\\**freetype.lib** | `34200337A0BBD160C70446168A8CF8B3AE15B9A43ABF5CF8DE073C74FA3C722D` |
| win64\\**freetype.dll** | `8DAA6A41822268836052D1DEE20E24A6329FBEA7DBBBABAC73B789321074EAAD` |
| win64\\**freetype.lib** | `5A0041D6CB8D4BAE85CFC8A1F86F0C749DC647B64FF96564B4419D9868A4EEAF` |
